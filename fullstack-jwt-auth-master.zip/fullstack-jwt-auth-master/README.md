### Подписывайся на TeleGram канал - https://t.me/ulbi_tv
##
### PDF версия урока здесь - https://www.patreon.com/ulbitv
